angular.module("myApp", []).controller("myCtrl", function ($scope) {
    $scope.items=[];

    $scope.calculateManMonths = function(){
        var nManMonths = 0;
        if($scope.language == "C"){
            nManMonths = $scope.functionpoints / 9.07;
        }else if($scope.language == "VB.net"){
            nManMonths = $scope.functionpoints / 20.90;
        }else if($scope.language == "AML"){
            nManMonths = $scope.functionpoints / 15.38;
        }else if($scope.language == "C#"){
            nManMonths = $scope.functionpoints / 14.85;
        }else if($scope.language == "PHP"){
            nManMonths = $scope.functionpoints / 13.64;
        }else if($scope.language == "EIFFEL"){
            nManMonths = $scope.functionpoints / 20.90;
        }else if($scope.language == "FOCUS"){
            nManMonths = $scope.functionpoints / 16.75;
        }else if($scope.language == "Haskell"){
            nManMonths = $scope.functionpoints / 17.15;
        }else if($scope.language == "GML"){
            nManMonths = $scope.functionpoints / 15.87;
        }else if($scope.language == "KL"){
            nManMonths = $scope.functionpoints / 13.64;
        }else if($scope.language == "SYBASE"){
            nManMonths = $scope.functionpoints / 16.75;
        }else if($scope.language == "WATFOR"){
            nManMonths = $scope.functionpoints / 11.29;
        }
        $scope.manmonths = Number(nManMonths.toFixed(2));
    }
});
