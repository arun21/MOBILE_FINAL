# jasmineAngularManMonths
This is a starting point for PROG8110 final

It is just tests and an implementation. To run it:

1. `browser-sync start --server --files "./*"`
1. surf to localhost:3000/manmonthtestrunner.html"


